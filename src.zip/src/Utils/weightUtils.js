export function roundToIncrement(value, increment = 2.5) {
  return Math.round(value / increment) * increment;
}

export function kgToLb(kg) {
  return kg * 2.20462;
}

export function lbToKg(lb) {
  return lb / 2.20462;
}

export const formatNum = (num) => {
  const n = parseFloat(num);
  if (isNaN(n)) return 0;
  return parseFloat(n.toFixed(2));
};